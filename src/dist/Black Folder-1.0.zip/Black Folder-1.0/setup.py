#!/usr/bin/env python

from distutils.core import setup

setup(name = "Black Folder",
      version = "1.0",
      description = "The Philo-Filer file organisation tool",
      author = "Brij Mohan Lal Srivastava",
      author_email = "contactbrijmohan@gmail.com",
      url = "http://srivastavabrij.blogspot.com/",
      py_modules = ["dropSite",
                  "extpathstore",
                  "systray_rc",
                  ""],
      data_files = [("", ["allPaths.db",
                            "currDirList.db",
                            "systray.qrc",
                            "transaction.db"]),
                    ("src/images", ["images/folder.ico",
                                       "images/folder.svg"])]
      )